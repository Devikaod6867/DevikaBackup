//
//  TitlePreviewViewController.swift
//  Cinevers
//
//  Created by MAC on 05/04/23.
//

import UIKit
import WebKit

class TitlePreviewViewController: UIViewController {
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 22, weight: .bold)
        label.text = "harry potter"
        return label
    }()
    
    private let overviewLabal: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 18 , weight: .regular)
        label.numberOfLines = 0 // it can take multiple lines
        label.text = "This is the better movie option"
        return label
        
    }()
    
    private let downloadButton: UIButton = {
        
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .red
        button.setTitle("Download", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.layer.masksToBounds = true
        return button
        
    }()
    
    
    private let webView: WKWebView = {
        
        let webView = WKWebView()
        webView.translatesAutoresizingMaskIntoConstraints = false
        return webView
        
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .systemBackground
        view.addSubview(webView)
        view.addSubview(titleLabel)
        view.addSubview(overviewLabal)
        view.addSubview(downloadButton)
      
        configuareConstrain()
    }
    
    func configuareConstrain() {
        
        let webViewConstrain = [
            webView.topAnchor.constraint(equalTo: view.topAnchor, constant: 50),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.heightAnchor.constraint(equalToConstant: 250 )
        ]
        
        let titleLabelConstrains = [
            titleLabel.topAnchor.constraint(equalTo: webView.bottomAnchor, constant: 20),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20)
        ]
        
        let overViewLabalConstrain = [
        
            overviewLabal.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 15),
            overviewLabal.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            overviewLabal.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ]
        
        let downloadButoonContrain = [
             
            downloadButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            downloadButton.topAnchor.constraint(equalTo: overviewLabal.bottomAnchor, constant: 25),
            downloadButton.widthAnchor.constraint(equalToConstant: 140),
            downloadButton.heightAnchor.constraint(equalToConstant: 40)
        ]
        
        NSLayoutConstraint.activate(webViewConstrain)
        NSLayoutConstraint.activate(titleLabelConstrains)
        NSLayoutConstraint.activate(overViewLabalConstrain)
        NSLayoutConstraint.activate(downloadButoonContrain)
    }
    
    func configure(with model: titlePreviewViewModel){
        
        titleLabel.text = model.title
        overviewLabal.text = model.titleOverview
        
        guard let url = URL(string: "https://www.youtube.com/embed/\(model.youtubeView.id.videoId)") else{
            print("Invalid URL!!!")
            return
        }
        webView.load(URLRequest(url: url))
    }
}

