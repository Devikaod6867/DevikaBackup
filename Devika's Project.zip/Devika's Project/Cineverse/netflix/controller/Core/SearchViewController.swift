//
//  SearchViewController.swift
//  netflix
//
//  Created by MAC on 03/04/23.
//

import UIKit
//import XCTest

class SearchViewController: UIViewController {
    
    private var titles: [Movie] = [Movie]()
    
    
    private let DiscoverTable: UITableView = { // this is for table view
        let table = UITableView()
        table.register(TitleTableViewCell.self, forCellReuseIdentifier: TitleTableViewCell.identifier)
        return table
    }()
    
    
    private let searchController: UISearchController = { // add seasrch bar in this page to the top side
        let controller = UISearchController(searchResultsController: SearchResultsViewController())
        controller.searchBar.placeholder = "search for movie or Tv show"
        controller.searchBar.searchBarStyle = .minimal
        return controller
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Search" // for search icone_0
        navigationController?.navigationBar.prefersLargeTitles = true // for search icone_1
        navigationController?.navigationItem.largeTitleDisplayMode = .always // for search icone_2
        
        
        view.backgroundColor = .systemBackground
        
        view.addSubview(DiscoverTable)
        DiscoverTable.delegate = self // pass data and pass number of rows
        DiscoverTable.dataSource = self
        
        navigationItem.searchController = searchController
        navigationController?.navigationBar.tintColor = .white // it is for cancel button which color is white
        
        fetchDicoverMovie()
        
        searchController.searchResultsUpdater = self
    }
        
    private func fetchDicoverMovie(){
        APICaller.shared.getDiscoverMovie { [weak self] Result in
            switch Result{
            case .success(let titles):
                self?.titles = titles
                DispatchQueue.main.async {
                    self?.DiscoverTable.reloadData()
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        DiscoverTable.frame = view.bounds
    }
}

extension SearchViewController: UITableViewDataSource , UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: TitleTableViewCell.identifier, for: indexPath) as? TitleTableViewCell else {
            return UITableViewCell()
        }
        
        let title = titles[indexPath.row]
        let model = TitleViewModel(titleName: title.originalTitle ?? title.originalName ?? "unknowen" , posterURL: title.posterPath ?? "")
        cell.configure(with: model)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let title = titles[indexPath.row]
        
        guard let titleName = title.originalName ?? title.originalTitle else{
            return
        }
        
        APICaller.shared.getMovie(With: titleName) { [weak self]Result in
            switch Result{
            case .success(let videoElment):
                DispatchQueue.main.async {
                    let vc = TitlePreviewViewController()
                    vc.configure(with: titlePreviewViewModel(title: titleName, youtubeView: videoElment, titleOverview: title.overview ?? ""))
                    self?.navigationController?.pushViewController(vc, animated: true)
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}

extension SearchViewController: UISearchResultsUpdating, SearchResultsViewControllerDeleget{
    
    func updateSearchResults(for searchController: UISearchController) {
        let searchBar = searchController.searchBar
        
        guard let quary = searchBar.text,
              !quary.trimmingCharacters(in: .whitespaces).isEmpty,
              quary.trimmingCharacters(in: .whitespaces).count >= 3,
              let resultCotroller = searchController.searchResultsController as? SearchResultsViewController else{
                  return
              }
        
        resultCotroller.gelegate = self
        
        APICaller.shared.search(with: quary) { result in
            DispatchQueue.main.async {
                switch result{
                case .success(let titles):
                    resultCotroller.titles = titles
                    resultCotroller.searchResultsCollectionView.reloadData()
                case .failure(let error):
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    func SearchResultsViewControllerDidTapItem(_ viewModel: titlePreviewViewModel) {
        
        DispatchQueue.main.async {[weak self] in
            let vc = TitlePreviewViewController()
            vc.configure(with: viewModel)
            self?.navigationController?.pushViewController(vc, animated: true)
        }
       
    }
    
    
    
}

