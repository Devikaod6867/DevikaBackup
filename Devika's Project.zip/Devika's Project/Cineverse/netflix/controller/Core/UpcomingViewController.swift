//
//  UpcomingViewController.swift
//  netflix
//
//  Created by MAC on 03/04/23.
//

import UIKit
//import XCTest
//import XCTest

class UpcomingViewController: UIViewController {
    private var titles: [Movie] = [Movie]() // create variable for fatch only the data from the imdb site
    
    
    private let UpComingTable: UITableView = { // this is for table view
        
        let table = UITableView()
        table.register(TitleTableViewCell.self, forCellReuseIdentifier: TitleTableViewCell.identifier)
        return table
    }()

    override func viewDidLoad() { // main block
        super.viewDidLoad()

        view.backgroundColor = .systemBackground
        title = "UpComimg"
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.navigationItem.largeTitleDisplayMode = .always
    
    view.addSubview(UpComingTable)
    UpComingTable.delegate = self
    UpComingTable.dataSource = self
        
        fetchUpComing() // call the list function
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        UpComingTable.frame = view.bounds
    }
    
    private func fetchUpComing(){ // get a list of the upcoming  movie
        APICaller.shared.GetUpComimgMovies { [weak self ] result in
            switch result {
            case .success(let titles):
                self?.titles = titles
                DispatchQueue.main.async {
                    self?.UpComingTable.reloadData()
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}


extension UpcomingViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: TitleTableViewCell.identifier, for: indexPath) as? TitleTableViewCell else{
            return UITableViewCell()
        }
        
        let title = titles[indexPath.row]
        cell.configure(with: TitleViewModel(titleName: (title.originalTitle ?? title.originalName) ?? "unknown name", posterURL: title.posterPath ?? " "))
        return cell
    }
    
    //fix row hight
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let title = titles[indexPath.row]
        
        guard let titleName = title.originalName ?? title.originalTitle else{
            return
        }
        
        APICaller.shared.getMovie(With: titleName) { [weak self]Result in
            switch Result{
            case .success(let videoElment):
                DispatchQueue.main.async {
                    let vc = TitlePreviewViewController()
                    vc.configure(with: titlePreviewViewModel(title: titleName, youtubeView: videoElment, titleOverview: title.overview ?? ""))
                    self?.navigationController?.pushViewController(vc, animated: true)
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
