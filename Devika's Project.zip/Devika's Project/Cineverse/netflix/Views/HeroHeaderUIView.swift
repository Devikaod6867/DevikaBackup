//
//  HeroHeaderUIView.swift
//  netflix
//
//  Created by MAC on 03/04/23.
//

import UIKit

class HeroHeaderUIView: UIView {
    
    //add one download button
    private let downloadbutton: UIButton = {
        let button = UIButton()
        button.setTitle("Download", for: .normal)
        button.layer.borderColor = UIColor.white.cgColor  // frame color white
        button.layer.borderWidth = 1
        button.translatesAutoresizingMaskIntoConstraints = true //  use constrain in here
        button.layer.cornerRadius = 5
        button.backgroundColor = .systemBackground
        return button 
    }()
    
    
    
    //add one button
    private var playbutton: UIButton = {
        
        let button = UIButton()
        button.setTitle("Play", for: .normal)
        button.layer.borderColor = UIColor.white.cgColor  // frame color white
        button.layer.borderWidth = 1
        button.translatesAutoresizingMaskIntoConstraints = true //  use constrain in here
        button.layer.cornerRadius = 5
        button.backgroundColor = .systemBackground
        //button.textColor = UIColor.black
        // button.backgroundColor = .black
        return button
    }()

   // task:- give frame and insite the frame assign the three frame-uiimage,2 buttom(download,play)
    private let heroimageview: UIImageView = {
       let imageview = UIImageView()
        imageview.contentMode = .scaleToFill
        imageview.clipsToBounds = true
        imageview.image = UIImage(named: "OmShantiOm_img")
        imageview.backgroundColor = .systemBackground
        return imageview
    }()//image view wich contain header
    
    private func gradient(){
        let gradiantLayer = CAGradientLayer()
        gradiantLayer.colors = [
            UIColor.label.cgColor,
            UIColor.systemBackground.cgColor
        ]// make mixture color background of one page
        
        //give frame to gradiant layer
        gradiantLayer.frame = bounds
        gradiantLayer.zPosition = -1
        layer.addSublayer(gradiantLayer)
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(heroimageview)
        gradient()
        addSubview(playbutton)
        addSubview(downloadbutton)
        applyconstrain()
        
    }
    
    private func applyconstrain() {
        let playButtonConstrain = [ playbutton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 90),
                                    playbutton.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -50),
                                    playbutton.widthAnchor.constraint(equalToConstant: 100)
        ]//give constain to button
        
        let downloadbuttonconstrain = [
                                downloadbutton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -90),
                                downloadbutton.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -50),
                                downloadbutton.widthAnchor.constraint(equalToConstant: 100)
        ]
        
        NSLayoutConstraint.activate(playButtonConstrain)
        NSLayoutConstraint.activate(downloadbuttonconstrain)
    }//use a english language voice
    
    public func configure(with model: TitleViewModel){
        guard let url = URL(string: "https://image.tmdb.org/t/p/w500/\(model.posterURL)") else{
            return
        }
        
        heroimageview.sd_setImage(with: url, completed: nil)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        heroimageview.frame = bounds
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
}
