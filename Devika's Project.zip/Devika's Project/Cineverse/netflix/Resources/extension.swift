//
//  extension.swift
//  Cinevers
//
//  Created by MAC on 04/04/23.
//

import Foundation

extension String {
    
    func capitalizeFiestLetter() -> String{
        
        return self.prefix(1).uppercased() + self.lowercased().dropFirst()
    
    }
}
