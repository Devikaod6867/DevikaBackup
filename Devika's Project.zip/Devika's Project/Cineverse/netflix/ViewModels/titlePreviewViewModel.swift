//
//  titlePreviewViewModel.swift
//  Cinevers
//
//  Created by MAC on 05/04/23.
//

import Foundation
struct titlePreviewViewModel{
    
    let title: String
    let youtubeView: VideoElement
    let  titleOverview: String
    
}
