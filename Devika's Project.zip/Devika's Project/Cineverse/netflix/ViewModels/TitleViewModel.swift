//
//  TitleViewModel.swift
//  Cinevers
//
//  Created by MAC on 05/04/23.
//

import Foundation
struct TitleViewModel {
    let titleName: String
    let posterURL: String
    
}
