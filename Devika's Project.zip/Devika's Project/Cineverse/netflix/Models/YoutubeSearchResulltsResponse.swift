//
//  YoutubeSearchResponse.swift
//  Cinevers
//
//  Created by MAC on 05/04/23.
//

import Foundation
/*items =     (
            {
        etag = "40AuTVj-ZyCcl9OwlQAUDL7H3KM";
        id =             {
            kind = "youtube#video";
            videoId = 8xih2E2Mpdo;
        };
        kind = "youtube#searchResult";
    },*/

struct YoutubeSearchResulltsResponse: Codable{
    
    let items: [VideoElement]
    
}

struct VideoElement: Codable{
    
    let id: IdVideoElement
    
}
struct IdVideoElement: Codable{
    let kind: String
    let videoId: String
}
