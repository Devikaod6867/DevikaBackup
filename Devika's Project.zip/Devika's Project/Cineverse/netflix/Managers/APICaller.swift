//
//  APICaller.swift
//  Cinevers
//
//  Created by MAC on 04/04/23.
//

import Foundation
import UIKit

struct constants{
    static let API_KEY = "271e85e34fd450e751a8157a7a02ca99"
    static let baseURL = "https://api.themoviedb.org"
    static let YoutubeAPI_Key = "AIzaSyCRtt6OoVBlUGWL9cTerNBTxXoHuyCF6nI"
    static let YoutubeBaseURL = "https://youtube.googleapis.com/youtube/v3/search?"
}
//https://youtube.googleapis.com/youtube/v3/search?q=harry&key=[YOUR_API_KEY]
enum APIError: Error{
    case failedToGetData
}


class APICaller {
    
    static let shared = APICaller()
    
    func getTrendingmovie(complition: @escaping (Result<[Movie], Error>) -> Void){
        guard let url = URL(string: "\(constants.baseURL)/3/trending/movie/day?api_key=\(constants.API_KEY)") else{
            return
        }
        let task = URLSession.shared.dataTask(with: URLRequest(url: url)) { data, request, error  in
            
            guard let data = data, error == nil else{
                return
            }
            do{
                let results = try JSONDecoder().decode(TrendingMovieResponse.self, from: data)
                complition(.success(results.results!))
            }
            catch{
                complition(.failure(error))
            }
        }
        task.resume()
    }
    
    func getTrendingTv(complition: @escaping (Result<[Movie], Error>) -> Void){
        guard let url = URL(string: "\(constants.baseURL)/3/trending/tv/day?api_key=\(constants.API_KEY)") else{
            return
        }
        let task = URLSession.shared.dataTask(with: URLRequest(url: url)) { Data, _, error in
            guard let Data = Data, error == nil else {
                return
            }
            do{
                let results = try JSONDecoder().decode(TrendingMovieResponse.self, from: Data)
                complition(.success(results.results!))
            }
            catch{
                complition(.failure(APIError.failedToGetData))
            }
        }
        task.resume()
    }
    
    func GetUpComimgMovies(complition: @escaping (Result<[Movie], Error>) -> Void){
        guard let url = URL(string: "\(constants.baseURL)/3/movie/upcoming?api_key=\(constants.API_KEY)&language=en-US&page=1")else {return}
        let task = URLSession.shared.dataTask(with: URLRequest(url: url)) { Data, _, Error in
            guard let Data = Data, Error == nil else {
                return
            }
            do{
                let results = try JSONDecoder().decode(TrendingMovieResponse.self, from: Data)
                complition(.success(results.results!))
            }
            catch{
                complition(.failure(APIError.failedToGetData))
            }

        }
        task.resume()
    }
    
    func getPopular(complition: @escaping (Result<[Movie], Error>) -> Void){
        guard let url = URL(string: "\(constants.baseURL)/3/movie/popular?api_key=\(constants.API_KEY)") else{return}
        let task = URLSession.shared.dataTask(with: URLRequest(url: url)) { Data, _, Error in
            guard let Data = Data, Error == nil else {
                return
            }
            do{
                let results = try JSONDecoder().decode(TrendingMovieResponse.self, from: Data)
                complition(.success(results.results!))
            }
            catch{
                complition(.failure(APIError.failedToGetData))
            }

        }
        task.resume()
    }
    
    func getTopRated(complition: @escaping (Result<[Movie], Error>) -> Void){
        guard let url = URL(string: "\(constants.baseURL)/3/movie/top_rated?api_key=\(constants.API_KEY)") else{return}
        let task = URLSession.shared.dataTask(with: URLRequest(url: url)) { Data,_, Error in
            guard let Data = Data, Error == nil else {
                return
            }
            do{
                let results = try JSONDecoder().decode(TrendingMovieResponse.self, from: Data)
                complition(.success(results.results!))
            }
            catch{
                complition(.failure(APIError.failedToGetData))
            }

        }
        task.resume() //task display on simulator panal
    }
    
    
    func getDiscoverMovie(complition: @escaping(Result<[Movie], Error>) -> Void){
        guard let url = URL(string: "\(constants.baseURL)/3/discover/movie?api_key=\(constants.API_KEY)&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1&with_watch_monetization_types=flatrate") else{return}
        
        let task = URLSession.shared.dataTask(with: URLRequest(url: url)) { Data,_, Error in
            guard let Data = Data, Error == nil else {
                return
            }
            do{
                let results = try JSONDecoder().decode(TrendingMovieResponse.self, from: Data)
                complition(.success(results.results!))
            }
            catch{
                complition(.failure(APIError.failedToGetData))
            }
        }
        task.resume()
    }
    
    func search(with quary: String, complition: @escaping(Result<[Movie], Error>) -> Void){
        
        guard let quary = quary.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) else{return}
        
        guard let url = URL(string: "\(constants.baseURL)/3/search/movie?api_key=\(constants.API_KEY)&query=\(quary)") else{return}
        
        let task = URLSession.shared.dataTask(with: URLRequest(url: url)) { Data,_, Error in
            guard let Data = Data, Error == nil else {
                return
            }
            do{
                let results = try JSONDecoder().decode(TrendingMovieResponse.self, from: Data)
                complition(.success(results.results!))
            }
            catch{
                complition(.failure(APIError.failedToGetData))
            }
        }
        task.resume()
    }
    
    func getMovie(With quary: String, complition: @escaping(Result<VideoElement, Error>) -> Void){
        
        guard let quary = quary.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) else{return}
        
        guard let url = URL(string: "\(constants.YoutubeBaseURL)q=\(quary)&key=\(constants.YoutubeAPI_Key)") else{return}
        let task = URLSession.shared.dataTask(with: URLRequest(url: url)) { Data,_, Error in
            guard let Data = Data, Error == nil else {
                return
            }
            do{
                let results = try JSONDecoder().decode(YoutubeSearchResulltsResponse.self, from: Data)
                complition(.success(results.items[0]))
            }
            catch{
                complition(.failure(error))
               
            }
        }
        task.resume()
        
    }
    
}

//https://api.themoviedb.org/3/search/movie?api_key={api_key}&query=Jack+Reacher

    

