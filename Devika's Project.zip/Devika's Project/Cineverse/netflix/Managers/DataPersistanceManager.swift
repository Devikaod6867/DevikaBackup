//
//  DataPersistanceManager.swift
//  Cinevers
//
//  Created by MAC on 06/04/23.
//

import Foundation
import UIKit
import CoreData
// downloading data and also talk with core data API
class DataPersistanceManager {
    
    enum DataBaseError : Error{
        case faildToSaveData
        case failToFatchData
        case failToDeletData
    }
    
    static let shared = DataPersistanceManager()
    
    func downloadTitleWith(model: Movie, completion: @escaping (Result<Void, Error>) -> Void){
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        
        
        let context = appDelegate.persistentContainer.viewContext // talk to th context manager
        
        let item = TitleItem(context: context) //store inside the database
        
        item.originalName = model.originalName
        item.id = Int64(model.id)
        item.originalTitle = model.originalTitle
        item.overview = model.overview
        item.posterPath = model.posterPath
        item.mediaType = model.mediaType
        item.releaseDate = model.releaseDate
        item.voteCount = Int64(model.voteCount ?? 00)
        item.voteAverage = model.voteAverage ?? 00
        
        do{
            context.insert(item)
            try context.save()
            completion(.success(()))
        }catch{
            completion(.failure(DataBaseError.faildToSaveData))
        }
    }
    
    func fetchingTitleFromDataBase(complition: @escaping (Result<[TitleItem], Error>) -> Void){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        
        let context = appDelegate.persistentContainer.viewContext
        
        //talk again with context manager
        let request: NSFetchRequest<TitleItem>
        request = TitleItem.fetchRequest()
        
        
        do{
            
          let titles = try context.fetch( request)
            complition(.success(titles))
        }
        catch{
            complition(.failure(DataBaseError.failToFatchData))

        }
    }
    func deletTitleItem(model: TitleItem, completion: @escaping (Result<Void, Error>) -> Void){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        
        let context = appDelegate.persistentContainer.viewContext
        
        context.delete(model) // asking the database manager to delet object
        
        do{
            try context.save()
            completion(.success(()))
        }
        catch{
          
            completion(.failure(DataBaseError.failToDeletData))
            
        }
    }
     
}
